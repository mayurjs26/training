/**
 * 
 */
package com.capgemini.lab2.dao;

import java.util.List;

import com.capgemini.lab2.entities.Book;

/**
 * @author mayur shinde
 * 
 *
 */
public interface Lab2Dao {
	public List<Book> fetchAllBooks();

}
