/**
 * 
 */
package com.capgemini.lab2.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.lab2.entities.Book;

/**
 * @author mayur shinde
 *
 */
public class Lab2DaoImpl implements Lab2Dao {
	EntityManager em;
	

	public Lab2DaoImpl() {
		em = JPAUtil.getEntityManager();
	}

	@Override
	public List<Book> fetchAllBooks( ) {
		
		String qStr = "SELECT book FROM Book book";
		TypedQuery<Book> query = em.createNamedQuery(qStr, Book.class);
		List<Book> book =query.getResultList();
		
		return book;
	}

}
