/**
 * 
 */
package com.capgemini.lab2.service;

import com.capgemini.lab2.entities.Author;



/**
 * @author mayur shinde
 *
 */
public interface Lab2Service {
	

}
