Demo 1 
Use below URL in postman:
1. Get all countries
http://localhost:8081/SpringRESTDemowithException/rest/countries

2. Search country for id 1001 result found
http://localhost:8081/SpringRESTDemowithException/rest/countries/search/1001

3 Search country for id 100 result found
http://localhost:8081/SpringRESTDemowithException/rest/countries/search/100
See the user defined error message

Demo 2
Use below URL in postman:
1. Get all countries
http://localhost:8081/SpringRESTDemowithGlobalException/rest/countries

2. Search country for id 1001 result found
http://localhost:8081/SpringRESTDemowithGlobalException/rest/countries/search/1001

3 Search country for id 100 result found
http://localhost:8081/SpringRESTDemowithGlobalException/rest/countries/search/100
See the user defined error message