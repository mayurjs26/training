package com.capgemini.idbi.dao;

import com.capgemini.idbi.bean.Customer;
import com.capgemini.idbi.bean.Loan;

public interface IDao {
	public Loan applyLoan(Loan loan);
	public Customer insertCustomer(Customer customer);

}
