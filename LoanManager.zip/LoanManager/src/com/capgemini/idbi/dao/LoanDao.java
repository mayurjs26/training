package com.capgemini.idbi.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.idbi.bean.Customer;
import com.capgemini.idbi.bean.Loan;

public class LoanDao implements IDao{
	Map<Double,Customer> customerEntry = new HashMap<Double, Customer>();
	Map<Long, Loan> loanEntry = new HashMap<Long, Loan>();
	
	
	public Customer insertCustomer(Customer customer) {
		double temp =  Math.floor(Math.random()*1000);
		
		
		customerEntry.put(temp, customer);
		customer.setCustId(temp);
		
		
		
		return customer;
		
	}
	
	public Loan applyLoan(Loan loan) {
		
		long temp = (long)Math.floor(Math.random()*1000);
		loanEntry.put(temp, loan);
		loan.setLoanID(temp);;
		
		
		
		
		return loan;
		
	}
	
	
	public Customer fetch(double cusid) {
		for (Customer c : customerEntry
				) {
			
		}
		
		
		return null;
		
	}

}
