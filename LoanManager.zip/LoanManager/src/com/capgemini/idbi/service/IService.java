package com.capgemini.idbi.service;

public interface IService {
	
	String namePattern = "[a-zA-Z]{2,}";
	String addressPattern = "^[#.0-9a-zA-Z\\s,-]+$";

}
