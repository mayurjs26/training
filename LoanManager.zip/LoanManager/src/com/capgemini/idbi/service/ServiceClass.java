package com.capgemini.idbi.service;

import com.capgemini.idbi.bean.Customer;
import com.capgemini.idbi.bean.Loan;
import com.capgemini.idbi.dao.IDao;
import com.capgemini.idbi.dao.LoanDao;

public class ServiceClass implements IService {
	IDao dao = new LoanDao();
	public Customer insertCustomer(Customer customer) {
		return dao.insertCustomer(customer);
	}
	
	public Loan applyLoan(Loan loan) {
		return dao.applyLoan(loan);
	}
	
	public double calculateEMI(double amount,int duration) {
		double roi = 0.095;
		double temp = Math.pow((1+roi), duration);
		double emi = (amount*roi*temp)/(temp-1);
		
		return emi;
	}
	
	
	public boolean validateName(String name) {
		if(name.matches(namePattern)) {
			return true;
		}
		else
			return false;
	}

	public boolean validateAddress(String name) {
		if(name.matches(addressPattern)) {
			return true;
		}
		else
			return false;
	}
}
