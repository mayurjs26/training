package com.capgemini.idbi.ui;

import java.util.Scanner;

import com.capgemini.idbi.bean.Customer;
import com.capgemini.idbi.bean.Loan;
import com.capgemini.idbi.service.ServiceClass;

public class ExecuteMain {
	public static void main(String[] args) {
		String name;
		String mobileNo;
		String address;
		String email;
		ServiceClass serviceClass = new ServiceClass();
		Loan loan  = new Loan();
		Customer customer = new Customer();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("IDBI Finance Comapany Welcomes You");
		System.out.println("1.Register Customer\n 2.Exit");
		System.out.println("Please Enter a Valid Choice");
		int choice = sc.nextInt();
		if(choice==1) {
			
			while(true) {
			System.out.println("Please Enter Your Name:");
			name = sc.next();
			boolean isValid = serviceClass.validateName(name);
			if(isValid) {
				customer.setCustName(name);
				break;
			}
			
		}
			
			while(true) {
				System.out.println("Enter your Address");
				address = sc.next();
				boolean isValid = serviceClass.validateAddress(address);
				if(isValid) {
					customer.setAddress(address);
					break;
				}
			}
			
			System.out.println("Enter your Mobile No:");
			mobileNo = sc.next();
			customer.setMobile(Long.parseLong(mobileNo));
			
			
			System.out.println("Enter your Email");
			email = sc.next();
			customer.setEmail(email);
			
			Customer cust = serviceClass.insertCustomer(customer);
			//System.out.println(cust);
			loan.setCustId(cust.getCustId());
			System.out.println("Customer information saved succesfully");
			System.out.println("Customer is created with : "+cust.getCustId());
			
			System.out.println("Do you wish to apply for Loan");
			String choice1 = sc.next();
			if(choice1.equalsIgnoreCase("yes")) {
				
				//Loan loanCustomer = serviceClass.applyLoan(loan);
				System.out.println("Enter the loan amount");
				double amount = sc.nextDouble();
				loan.setLoanAmount(amount);
				System.out.println("Enter the loan duration");
				int duration = sc.nextInt();
				loan.setDuration(duration);
				System.out.println("for loan amount "+amount+"and"+duration+"years of duration");
				System.out.println("your calculated emi is"+serviceClass.calculateEMI(amount, duration));
				System.out.println("do you want to apply for loan now");
				String ch = sc.next();
				if(ch.equalsIgnoreCase("yes")) {
					Loan loanRequest = serviceClass.applyLoan(loan);
					System.out.println("login requested generated");
					System.out.println("your loan id"+loanRequest.getLoanID());
					System.out.println("thanks for visiting");
				}
				else if(ch.equalsIgnoreCase("no")) {
					System.out.println("thanks for visiting"+cust.getCustName());
				}
				
				
			}
			
			
			
			
	}
		else if(choice==2) {
			System.exit(0);
		}
		else {
			System.out.println("invalid input");
		}

	}
}
