package com.cg.mobshop.dao;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.PriceComparator;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO {
	
	List<Mobiles> mobiles;
	PriceComparator pc = new PriceComparator();

	@Override
	public List<Mobiles> getMobilesList() {
		for (Integer k : Util.getMobileEntries().keySet()) {
			List<Mobiles> mobiles = Arrays.asList(Util.getMobileEntries().get(k));         //getting the mobiles list in a list
		}
		
		
		return mobiles;
	}

	@Override
	public Mobiles deleteMobile(int mobcode) {
		for (Integer k : Util.getMobileEntries().keySet()) {
			if(k==mobcode){
				Util.getMobileEntries().remove(k);                                  // removing the specified mobile from the list
			}
			return Util.getMobileEntries().get(mobcode);
			
		}
		
		
		return null;
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		switch(criteria){
		case 2:
		{
			for (Integer k : Util.getMobileEntries().keySet()) {
				List<Mobiles> mobiles = Arrays.asList(Util.getMobileEntries().get(k));
				
			 mobiles.sort(pc);
			}
			return mobiles;
		}
		
		case 1:
		{
			
		}
		
		case 3:
		{
			
		}
		}
		
		
		return null;
	}

}
