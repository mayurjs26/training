function sayHello(){
    document.write("<h1 align: left> Hello World</h1> ");
}