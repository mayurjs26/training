package cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cg.bean.TrainingBean;
import cg.config.JdbcFactory;

public class TrainingDao implements ITrainingDao{

	Connection connection = null;
	PreparedStatement statement = null;
	
	public TrainingDao() {
			try {
				connection = JdbcFactory.getConnection();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	@Override
	public TrainingBean enroll(TrainingBean training) {
	
			try {
				statement = connection.prepareStatement("Update training set AvailableSeats=? where trainingId=?");
				
				statement.setInt(1, training.getAvailableSeats()-1);
				statement.setInt(2, training.getTrainingId());
				statement.executeUpdate();
				
				training.setAvailableSeats(training.getAvailableSeats()-1);
				return training;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
	}

	@Override
	public List<TrainingBean> showAll() {
		List<TrainingBean> tb = new ArrayList<>();
		try {
			statement = connection.prepareStatement(ALLDATA);
			ResultSet set = statement.executeQuery();
			
			while(set.next())
			{
				TrainingBean trainingBean = new TrainingBean();
				trainingBean.setTrainingId(set.getInt(1));
				trainingBean.setTrainingName(set.getString(2));
				trainingBean.setAvailableSeats(set.getInt(3));
				tb.add(trainingBean);
			}
			return tb;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
