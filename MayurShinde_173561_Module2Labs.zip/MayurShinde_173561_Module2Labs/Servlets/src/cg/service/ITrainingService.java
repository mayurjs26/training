package cg.service;

import java.util.List;

import cg.bean.TrainingBean;

public interface ITrainingService {

	TrainingBean enroll(TrainingBean training);
	List<TrainingBean> showAll();
}
