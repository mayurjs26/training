package cg.service;

import java.util.List;

import cg.bean.TrainingBean;
import cg.dao.ITrainingDao;
import cg.dao.TrainingDao;

public class TrainingService implements ITrainingService{

	ITrainingDao dao;
	
	public TrainingService() {
		dao = new TrainingDao();
	}
	@Override
	public TrainingBean enroll(TrainingBean training) {
		// TODO Auto-generated method stub
		return dao.enroll(training);
	}
	@Override
	public List<TrainingBean> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

}
