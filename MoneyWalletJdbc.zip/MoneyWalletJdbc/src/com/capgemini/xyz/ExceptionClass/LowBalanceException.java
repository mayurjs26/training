package com.capgemini.xyz.ExceptionClass;

public class LowBalanceException extends Exception {
	
	public LowBalanceException() {
		
	}
	public LowBalanceException(String message) {
		super(message);
	}
}
