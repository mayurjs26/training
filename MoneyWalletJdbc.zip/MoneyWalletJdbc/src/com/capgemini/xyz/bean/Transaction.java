package com.capgemini.xyz.bean;

public class Transaction {

	//Transaction details
	private String type;
	private double amount, balance;
	private long mobNo;

	public Transaction() {
		
	}

	

	public Transaction(String type, double amount, double balance, long mobNo) {
		super();
		this.type = type;
		this.amount = amount;
		this.balance = balance;
		this.mobNo = mobNo;
	}



	//getters and setters
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public long getMobNo() {
		return mobNo;
	}

	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}

	//ovverriding toString() of object class
	@Override
	public String toString() {
		return "Transaction [type=" + type + ", amount=" + amount
				+ ", balance=" + balance + "]";
	}

}
