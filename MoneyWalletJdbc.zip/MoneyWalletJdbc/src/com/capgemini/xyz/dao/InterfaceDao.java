package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;

public interface InterfaceDao {

	// declaring abstract methods
	String deposit(Customer customer, double amount) throws NegativeAmountException, SQLException;

	String withdraw(Customer customer, double amount) throws LowBalanceException, SQLException;

	Customer login(long mobNo, String password) throws SQLException, InvalidCredentialsException;

	String insertCustomer(Customer customer, Connection connection) throws SQLException;

	double showBalance(Customer customer) throws SQLException;

	String fundTransfer(Customer senderCustomer, Customer receiverCustomer, Double amount) throws SenderReceiverSameException, LowBalanceException, NegativeAmountException, SQLException;

	Customer checkUser(long receiverMobNo) throws SQLException, InvalidCredentialsException;

	void printTransaction(long mobNo);
}
