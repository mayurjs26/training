package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.config.JdbcConfig;

public class JdbcClassDao implements InterfaceDao, QuerryMapper {

	PreparedStatement statement = null;
	Connection connection;
	ResultSet res = null;

	public JdbcClassDao() {
		try {
			connection = JdbcConfig.getConnection();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}

	// public JdbcClassDao(Connection connection) {
	// if(connection==null)
	// System.out.println("connection null in dao");
	// this.connection=connection;
	// }

	@Override
	public String deposit(Customer customer, double amount)
			throws NegativeAmountException, SQLException {

		// System.out.println(customer.getMobileNo());

		if (amount <= 0) {
			throw new NegativeAmountException("Amount should be greater than 0");
		} else {
			statement = this.connection
					.prepareStatement(QuerryMapper.updateBalanceQuery);
			statement.setDouble(1, (customer.getBalance() + amount));
			statement.setLong(2, customer.getMobileNo());
			statement.executeUpdate();

			customer.setBalance(customer.getBalance() + amount);
			return "Rs " + amount + " deposited successfully at "
					+ LocalDateTime.now() + " for mobile no: "
					+ customer.getMobileNo() + "\n Your updated balance is: "
					+ showBalance(customer);
		}
	}

	@Override
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException, SQLException {

		// System.out.println(customer.getBalance());

		if (amount <= customer.getBalance()) {
			statement = connection
					.prepareStatement(QuerryMapper.updateBalanceQuery);
			statement.setDouble(1, customer.getBalance() - amount);
			statement.setLong(2, customer.getMobileNo());

			statement.executeUpdate();

			customer.setBalance(customer.getBalance() - amount);

			return "Rs " + amount + " withdrawn successfully at "
					+ LocalDateTime.now() + " for mobile no: "
					+ customer.getMobileNo() + "\n Your updated balance is: "
					+ showBalance(customer);
		} else {
			throw new LowBalanceException("Your balance is low");
		}
	}

	@Override
	public Customer login(long mobNo, String password) throws SQLException,
			InvalidCredentialsException {

		statement = this.connection.prepareStatement(QuerryMapper.fetchQuery);
		statement.setLong(1, mobNo);
		statement.setString(2, password);
		statement.executeUpdate();

		ResultSet res = statement.getResultSet();
		if (res.next()) {
			Customer customer = new Customer();
			customer.setCustId(res.getDouble(1));
			customer.setName(res.getString(2));
			customer.setMobileNo(res.getLong(3));
			customer.setEmail(res.getString(4));
			customer.setBalance(res.getDouble(5));
			customer.setPassword(res.getString(6));
			return customer;
		} else {
			throw new InvalidCredentialsException(
					"Invalid username or password");
		}
	}

	@Override
	public String insertCustomer(Customer customer, Connection connection)
			throws SQLException {

		statement = this.connection
				.prepareStatement(QuerryMapper.insertDetails);

		statement.setString(1, customer.getName());
		statement.setLong(2, customer.getMobileNo());
		statement.setString(3, customer.getEmail());
		statement.setDouble(4, customer.getBalance());
		statement.setString(5, customer.getPassword());

		statement.executeUpdate();

		return "Registration successfull! your username is your mobile number: "
				+ customer.getMobileNo();
	}

	@Override
	public double showBalance(Customer customer) throws SQLException {

		statement = this.connection
				.prepareStatement(QuerryMapper.showBalanceQuery);
		statement.setLong(1, customer.getMobileNo());

		ResultSet res = statement.executeQuery();
		if (res.next())
			;
		return res.getDouble("BALANCE");
	}

	@Override
	public String fundTransfer(Customer senderCustomer,
			Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException, SQLException {

		if (senderCustomer.getMobileNo() == receiverCustomer.getMobileNo()) {

			throw new SenderReceiverSameException("Cannot send to yourself");

		}
		withdraw(senderCustomer, amount); // withdrawing amount from sender's
											// wallet
		deposit(receiverCustomer, amount); // depositing amount to receiver's
											// wallet

		return amount + " Rs transferred to mobile number: "
				+ receiverCustomer.getMobileNo()
				+ "\n Your updated balance is: " + showBalance(senderCustomer);
	}

	@Override
	public Customer checkUser(long receiverMobNo) throws SQLException,
			InvalidCredentialsException {
		statement = this.connection.prepareStatement(QuerryMapper.fetchQuery2);
		statement.setLong(1, receiverMobNo);
		statement.executeUpdate();

		ResultSet res = statement.getResultSet();
		if (res.next()) {
			Customer customer = new Customer();
			customer.setCustId(res.getDouble(1));
			customer.setName(res.getString(2));
			customer.setMobileNo(res.getLong(3));
			customer.setEmail(res.getString(4));
			customer.setBalance(res.getDouble(5));
			customer.setPassword(res.getString(6));
			return customer;
		} else {
			return null;
		}

	}

	@Override
	public void printTransaction(long mobNo) {
		// TODO Auto-generated method stub

	}

}
