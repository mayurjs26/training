package com.capgemini.xyz.dao;

public interface QuerryMapper {

	String insertDetails = "insert into customer99" + " values"
			+ "(custId.nextval,?,?,?,?,?)";
	
	String showBalanceQuery="select balance from customer99 where mobileNo= ?";
	
	String fetchQuery="select * from customer99 where mobileNo=? and password=?";
	
	String fetchQuery2="select * from customer99 where mobileNo=?";
	
	String updateBalanceQuery="update customer99 set balance=? where mobileno=? ";
	

}
