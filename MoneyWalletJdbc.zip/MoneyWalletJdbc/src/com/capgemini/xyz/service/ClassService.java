package com.capgemini.xyz.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.capgemini.xyz.ExceptionClass.InvalidCredentialsException;
import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.dao.ClassDao;
import com.capgemini.xyz.dao.InterfaceDao;
import com.capgemini.xyz.dao.JdbcClassDao;

public class ClassService implements InterfaceService {

	// Connection connection;
	InterfaceDao idao = new JdbcClassDao();

	// public ClassService(Connection connection2) {

	// this.connection=connection2;
	// if(connection==null)
	// System.out.println("connection null in service");
	// }
	// InterfaceDao idao = new JdbcClassDao(connection);
	public ClassService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean validateName(String name) {
		if (name.matches(userNamePattern)) { // user name regex validation
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(emailPattern)) { // email regex validation
			return true;
		} else
			return false;
	}

	@Override
	public boolean validateMobNo(String mobNo) {
		if (mobNo.matches(mobNoPattern)) { // mobile no regex validation
			return true;
		} else
			return false;
	}

	@Override
	public String deposit(Customer customer, double amount)
			throws NegativeAmountException, SQLException {
		return (idao.deposit(customer, amount)); // calling deposit method of
													// classDao

	}

	@Override
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException, SQLException {
		return (idao.withdraw(customer, amount)); // calling withdraw method of
													// classDao

	}

	@Override
	public Customer login(long mobNo, String password) throws SQLException, InvalidCredentialsException {
		return (idao.login(mobNo, password)); // calling login method of
												// classDao
	}

	@Override
	public boolean validatePassword(String password) {
		if (password.matches(paswordPattern)) { // password regex validation
			return true;
		} else
			return false;
	}

	@Override
	public String insertCustomer(Customer customer, Connection connection)
			throws SQLException {
		return (idao.insertCustomer(customer, null)); // calling insertCustomer
														// method
		// of
		// classDao

	}

	@Override
	public double showBalance(Customer customer) throws SQLException {
		return idao.showBalance(customer); // calling showBalance method of
											// classDao
	}

	@Override
	public String fundTransfer(Customer senderCustomer,
			Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException,
			NegativeAmountException, SQLException {
		return (idao.fundTransfer(senderCustomer, receiverCustomer, amount)); // calling
		// fundTransfer
		// method of
		// classDao

	}

	@Override
	public Customer checkUser(long receiverMobNo) throws SQLException, InvalidCredentialsException {
		return (idao.checkUser(receiverMobNo)); // calling checkUser method of
												// classDao
	}

	@Override
	public void printTransaction(long mobNo) {
		idao.printTransaction(mobNo); // calling printTransaction method of
										// classDao
	}

}
