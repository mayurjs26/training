package com.capgemini.xyz.test;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.xyz.ExceptionClass.LowBalanceException;
import com.capgemini.xyz.ExceptionClass.NegativeAmountException;
import com.capgemini.xyz.ExceptionClass.SenderReceiverSameException;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.ClassService;
import com.capgemini.xyz.service.InterfaceService;

public class FundTransferTest {

	InterfaceService service = null;

	@Before
	public void setUp() throws Exception {
		service = new ClassService();
	}

	// right inputs
	@Test
	public void checkFundTransfer() {

		Customer customer = new Customer("Tushar", "t@g.c", 4000, 8286703935L,
				56, "password");
		
		Customer customer2 = new Customer("dude", "d@g.c", 8000, 9869444389L,
				45, "passvcd");
		try {
			service.insertCustomer(customer, null);
			service.insertCustomer(customer2, null);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String result;
		try {
			result = service.fundTransfer(customer, customer2, 2000d);
			assertNotNull(result);
		} catch (SenderReceiverSameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (LowBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NegativeAmountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// wrong inputs
	// should print insufficient balance in console
	@Test
	public void checkFundTransfer2() {
		
			Customer customer = new Customer("Tushar", "t@g.c", 2000, 8286703935L,
					56, "password");
			Customer customer2 = new Customer("dude", "d@g.c", 8000, 9869444389L,
					45, "passvcd");
			
			try {
				service.insertCustomer(customer, null);
				service.insertCustomer(customer2, null);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			

			String result;
			try {
				result = service.fundTransfer(customer,
						customer2, 3000d);
				assertNotNull(result);
			} catch (SenderReceiverSameException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (LowBalanceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NegativeAmountException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

	@After
	public void destroy() throws Exception {
		service = null;
	}
}
