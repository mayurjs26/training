package com.capgemini.citi.dao;

public interface IDao {
	void withdraw(double amount,long mobNo);
	void deposit(double amount,long mobNo);
	void fundTransfer(double amount,long mobNo1,long mobNo2);
	boolean login(String mobNo);

}
