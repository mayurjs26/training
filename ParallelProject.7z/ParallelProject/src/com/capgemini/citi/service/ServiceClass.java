package com.capgemini.citi.service;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.dao.DaoClass;

public class ServiceClass implements IService {
	DaoClass dao = new DaoClass();

	@Override
	public boolean validateName(String name) {
		if(name.matches(NamePattern))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		if(mobile.matches(mobilePattern))
			return true;
		else
		return false;
	}
	
	public boolean validateUsername(String username){
		if(username.matches(userNamePattern)){
			return true;
		}
		else
			return false;
		
	}

	@Override
	public boolean validateEmail(String email) {
		if(email.matches(emailPattern))
			return true;
		else
		return false;
	}
	
	public boolean validatePassword(String password){
		if(password.matches(passwordPattern))
			return true;
		else
		return false;
		
	}
	public void insertCustomer(Customer customer){
		dao.insertCustomer(customer);
	}
	
	public boolean checkCredentials(long mobileNo){
		
		
		return dao.checkCredentials(mobileNo);
		
	}
	public void deposit(double amount,long mobNo){
		dao.deposit(amount, mobNo);
	}
	
	public void withdraw(double amount,long mobNo){
		dao.withdraw(amount, mobNo);
	}
	
	public double showBalance(long mobNo){
		return dao.showBalance(mobNo);
	}
	
	public boolean login(long mobNo,String password){
		return dao.login(mobNo,password);
	}
	
	public void fundTransfer(long firstCustomer,long secondCustomer,double amount){
		dao.fundTransfer(amount, firstCustomer, secondCustomer);
	}
	public void printTransaction(long mobNo){
		dao.printTransaction(mobNo);
	}

}
