package com.capgemini.citi.ui;

import java.util.Scanner;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.dao.DaoClass;
import com.capgemini.citi.service.ServiceClass;

public class MainClass {

	public static void main(String[] args) {
		DaoClass dao = new DaoClass();
		Scanner scan = new Scanner(System.in);
		int choice = 0;
		boolean logOut;
		String name;
		String mobile;
		String email;
		String username;
		String password;
		ServiceClass service = new ServiceClass();
		Customer customer;// = new Customer();
		System.out
				.println("*******************Welcome To CiTi Bank Wallet********************");
		while (true) {
			System.out.println("Choose suitable option:");
			System.out.print("1.Register\n2.Login\n3.Exit\n");
			choice = scan.nextInt();
			switch (choice) {
			case 1: {
				customer = new Customer();
				System.out
						.println("Please Enter The Following Details to Register in the Wallet");

				while (true) {
					System.out.println("Enter your Name");
					name = scan.next();
					boolean isValid = service.validateName(name);
					if (isValid)
						customer.setName(name);
					break;

					// else
					// System.out.println("Please enter correct name");

				}

				while (true) {
					System.out.println("Enter Mobile:");
					mobile = scan.next();
					boolean isValid = service.validateMobile(mobile);
					if (isValid) {
						customer.setMobileNo(Long.parseLong(mobile));
						break;
					} else
						System.out.println("enter correct mobile no");

				}
				while (true) {
					System.out.println("Enter Email:");
					email = scan.next();
					boolean isValid = service.validateEmail(email);
					if (isValid) {
						customer.setEmail(email);
						break;
					}
				}

				while (true) {
					System.out.println("Enter Password");
					password = scan.next();
					boolean isValid = service.validatePassword(password);
					if (isValid) {
						customer.setPassword(password);
						break;
					}
				}

				service.insertCustomer(customer);
				System.out
						.println("Customer Registered Successfully\n Customer ID"
								+ customer.getCustId());
				System.out.println(customer.toString());
			}

				break;

			case 2: {
				System.out.println("Enter MobileNo And Password:");
				while (true) {
					System.out.println("Enter mob no");
					mobile = scan.next();
					boolean isValid = service.validateMobile(mobile);
					if (isValid)
						break;
				}

				while (true) {
					System.out.println("Enter Password");
					password = scan.next();
					boolean isValid = service.validatePassword(password);
					if (true)
						break;
				}

				boolean flag = service.login(Long.parseLong(mobile), password);
				// System.out.println("login");

				if (flag) {
					System.out.println("login successful");
					while (true) {

						System.out
								.println("***************************Menu for User to use Banking Facilities***********************");
						System.out
								.println("1.Show Balance\n 2.Deposit\n 3.Withdraw\n 4.Fund Transfer\n 5.Print Transaction\n 6.log out");
						choice = scan.nextInt();
						switch (choice) {
						case 1: {
							System.out.println(service.showBalance(Long
									.parseLong(mobile)));
							break;
						}
						case 2: {
							System.out.println("amount to deposit:");
							double amount = scan.nextDouble();
							service.deposit(amount, Long.parseLong(mobile));
							// //System.out.println("Current Balance "
							// + customer.getBalance() + "mobNo"
							// + customer.getMobileNo());
							break;
						}
						case 3: {
							System.out
									.println("Enter the amount to be withdrawn");
							double amount = scan.nextDouble();
							service.withdraw(amount, Long.parseLong(mobile));
							// System.out.println("Current balance"+customer.getBalance()+"mobNo:"+customer.getMobileNo());
							break;
						}
						case 4: {
							System.out
									.println("Enter the Mobile no of the receiver:");
							long receiverMobileNo = scan.nextLong();
							boolean validateReceiver = service
									.checkCredentials(receiverMobileNo);
							if (validateReceiver) {
								System.out
										.println("Enter the Amount to transfer");
								double amount = scan.nextDouble();
								service.fundTransfer(Long.parseLong(mobile),
										receiverMobileNo, amount);
								System.out
										.println("Amount Transferred Successfull");
							}

							break;
						}
						case 5: {
							service.printTransaction(Long.parseLong(mobile));
							break;
						}
						case 6:
							

						default:
							System.out.println("Invalid choice");
						}

					}

				}

			}
			case 3: {
				System.out.println("Thank You for Visiting us");
				System.exit(0);
				break;
			}
			default:
				System.out
						.println("Invalid Choice,Please Select from Numbers given");

			}

		}

	}
}
