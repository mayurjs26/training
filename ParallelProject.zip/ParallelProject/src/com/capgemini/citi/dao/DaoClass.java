package com.capgemini.citi.dao;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.bean.TransactionEntries;

public class DaoClass implements IDao {

	public Map<Long, Customer> accHolder = new HashMap<Long, Customer>();

	private List<TransactionEntries> transactDB = new ArrayList<TransactionEntries>();
	TransactionEntries tran;

	@Override
	public void withdraw(double amount, long mobNo) {
		// Customer customer =
		// accHolder.entrySet().stream().filter(x->x.getKey().equals(Long.parseLong(mobNo)).findFirst().get().getKey());
		if (amount > accHolder.get(mobNo).getBalance()) {
			System.out.println("Low Balance");
		}

		else {
			accHolder.get(mobNo).setBalance(
					accHolder.get(mobNo).getBalance() - amount);
			tran = new TransactionEntries("DR", amount, accHolder.get(mobNo)
					.getBalance());
			transactDB.add(tran);
		}

	}

	@Override
	public void deposit(double amount, long mobNo) {
		accHolder.get(mobNo).setBalance(
				accHolder.get(mobNo).getBalance() + amount);
		tran = new TransactionEntries("CR", amount, accHolder.get(mobNo)
				.getBalance());
		transactDB.add(tran);

	}

	@Override
	public void fundTransfer(double amount, long mobNo1, long mobNo2) {
		withdraw(amount, mobNo1);
		deposit(amount, mobNo2);

	}

	@Override
	public boolean login(String mobNo) {
		return false;
	}

	public void insertCustomer(Customer customer) {
		// /int temp = (int)Math.random()*100;
		customer.setCustId(Math.floor(Math.random() * 1000));
		accHolder.put(customer.getMobileNo(), customer);

		System.out.println("customer added:" + accHolder);

	}

	public boolean checkCredentials(long mobileNo) {
		for (Long key : accHolder.keySet()) {
			if (mobileNo == accHolder.get(key).getMobileNo()) {
				return true;
			}
		}
		return false;

	}

	public double showBalance(long mobileNo) {
		return accHolder.get(mobileNo).getBalance();
	}

	public boolean login(long mobNo, String password) {
		for (Long k : accHolder.keySet()) {
			if (k == mobNo && accHolder.get(k).getPassword().equals(password)) {
				return true;

			}
		}

		return false;

	}
	
	public void printTransaction(long mobNo){
		for(TransactionEntries t : transactDB){
			if(t.getMobNo()==mobNo){
				System.out.println(t);
			}
		}
	}

}
