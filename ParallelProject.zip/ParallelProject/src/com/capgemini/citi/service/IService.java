package com.capgemini.citi.service;

public interface IService {
	String NamePattern="[a-zA-Z]{2,20}";
	String mobilePattern = "(0/91)?[7-9][0-9]{9}";
	String emailPattern = "^[A-Za-z0-9+_.-]+@(.+)$";
	String userNamePattern ="[a-zA-Z0-9.\\-_]{3,}";
	String passwordPattern = "(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$";
	//String passwordPattern = 
	boolean validateName(String name);
	boolean validateMobile(String mobile);
	boolean validateEmail(String email);

}
