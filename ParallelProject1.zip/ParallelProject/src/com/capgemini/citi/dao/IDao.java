package com.capgemini.citi.dao;

import com.capgemini.citi.bean.Customer;

public interface IDao {
	void withdraw(double amount,long mobNo);
	void deposit(double amount,long mobNo);
	void fundTransfer(double amount,long mobNo1,long mobNo2);
    void insertCustomer(Customer customer);
	boolean checkCredentials(long mobileNo);
	public double showBalance(long mobileNo);
	public boolean login(long mobNo, String password);
	public void printTransaction(long mobNo);
	//boolean login(String mobNo);

}
