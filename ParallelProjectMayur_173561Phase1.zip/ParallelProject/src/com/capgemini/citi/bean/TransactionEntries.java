package com.capgemini.citi.bean;

public class TransactionEntries {
	private String type;
	private double amount,balance;
	private long mobNo;
	public TransactionEntries(String type, long mobNo, double balance,double d) {
		super();
		this.type = type;
		this.amount = d;
		this.balance = balance;
		this.mobNo = mobNo;
		//this.mobNo = mobNo;
	}
	
	public TransactionEntries(String type, double amount, double balance) {
		super();
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	@Override
	public String toString() {
		return "TransactionEntries [type=" + type + ", amount=" + amount + ", balance=" + balance + ", mobNo=" + mobNo
				+ "]";
	}
	
	

}
