package com.capgemini.citi.exception;

public class InsuffiecientBalanceException extends Exception {

	public InsuffiecientBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsuffiecientBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
