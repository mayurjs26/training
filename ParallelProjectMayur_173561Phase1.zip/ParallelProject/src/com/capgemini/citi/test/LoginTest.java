package com.capgemini.citi.test;

import static org.junit.Assert.*;

import org.junit.*;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.service.IService;
import com.capgemini.citi.service.ServiceClass;

public class LoginTest {
	IService service = null;
	Customer cust;

	@Before
	public void setUp() throws Exception {
		service = new ServiceClass();
	}

	@Test
	public void loginCheck() {
		Customer customer = new Customer("Tushar", "t@g.c", 4000, 8286703935L,
				"maydnhd");
		String test = service.insertCustomer(customer);
		Customer cust = service.login(8286703935L, "maydnhd");
		assertNotNull(cust);
	}

	@Test
	public void loginCheck2() {
		Customer customer = new Customer("Tushar", "t@g.c", 4000, 8286703935L,
				"password");
		service.insertCustomer(customer);

		cust = service.login(8286703935L, "maydnhd");
		assertNull(cust);

	}

	@After
	public void destroy() throws Exception {
		service = null;

	}

}