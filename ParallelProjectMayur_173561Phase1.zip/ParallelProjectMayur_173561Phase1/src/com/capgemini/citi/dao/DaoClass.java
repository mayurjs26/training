package com.capgemini.citi.dao;

import java.awt.image.SampleModel;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.bean.TransactionEntries;
import com.capgemini.citi.exception.CustomerNotFoundException;
import com.capgemini.citi.exception.InsuffiecientBalanceException;
import com.capgemini.citi.exception.SenderReceiverSameException;

public class DaoClass implements IDao {

	public Map<Long, Customer> accHolder = new HashMap<Long, Customer>();

	private List<TransactionEntries> transactDB = new ArrayList<TransactionEntries>();
	TransactionEntries tran;

	@Override
	public String withdraw(double amount, long mobNo) throws InsuffiecientBalanceException {
		// Customer customer =
		// accHolder.entrySet().stream().filter(x->x.getKey().equals(Long.parseLong(mobNo)).findFirst().get().getKey());
		if (amount > accHolder.get(mobNo).getBalance()) {
			throw new InsuffiecientBalanceException("You have Insufficient Balance");
		}

		else {
			accHolder.get(mobNo).setBalance(
					accHolder.get(mobNo).getBalance() - amount);
			tran = new TransactionEntries("DR", amount, accHolder.get(mobNo)
					.getBalance(),accHolder.get(mobNo).getMobileNo());
			transactDB.add(tran);
		}
		return "Rs " + amount + " withdrawn successfully at "
		+ LocalDateTime.now() + " for mobile no: " + mobNo
		+ "\n Your updated balance is: " + showBalance(mobNo);

	}

	@Override
	public String deposit(double amount, long mobNo) {
		accHolder.get(mobNo).setBalance(
				accHolder.get(mobNo).getBalance() + amount);
		tran = new TransactionEntries("CR", amount, accHolder.get(mobNo)
				.getBalance());
		transactDB.add(tran);
		return "Rs " + amount + " deposited successfully at "
				+ LocalDateTime.now() + " for mobile no: " + mobNo
				+ "\n Your updated balance is: " + showBalance(mobNo);

	}

	@Override
	public String fundTransfer(double amount, long mobNo1, long mobNo2) throws InsuffiecientBalanceException, SenderReceiverSameException {
		if(mobNo1==mobNo2){
			throw new SenderReceiverSameException();
		}
		
		withdraw(amount, mobNo1);
		
		deposit(amount, mobNo2);
		
		return amount + " Rs transferred to mobile number: " + mobNo1
				+ "\n Your updated balance is: " + showBalance(mobNo2);

	}

	

	public String insertCustomer(Customer customer) {
		// /int temp = (int)Math.random()*100;
		customer.setCustId(Math.floor(Math.random() * 1000));
		accHolder.put(customer.getMobileNo(), customer);
		
//		for(Long l:accHolder.keySet())
//			System.out.println(accHolder.get(l));

		//System.out.println("customer added:" + accHolder);
		return "Registration successfull! your username is your mobile number: "
		+ customer.getMobileNo();

	}

	public boolean checkCredentials(long mobileNo) {
		for (Long key : accHolder.keySet()) {
			if (mobileNo == accHolder.get(key).getMobileNo()) {
				return true;
			}
		}
		return false;

	}

	public double showBalance(long mobileNo) {
		return accHolder.get(mobileNo).getBalance();
	}

	public Customer login(long mobNo, String password) throws CustomerNotFoundException {
		for (Long key : accHolder.keySet()) {
			if (key == mobNo
					&& accHolder.get(key).getPassword().equals(password)) {
				return accHolder.get(key);
			}
		}
	
			
  return null;

	}
	
	public void printTransaction(long mobNo){
		for(TransactionEntries t : transactDB){
			if(t.getMobNo()==mobNo){
				System.out.println(t);
			}
		}
	}

}
