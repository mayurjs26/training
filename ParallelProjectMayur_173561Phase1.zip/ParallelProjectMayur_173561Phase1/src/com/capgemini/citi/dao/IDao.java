package com.capgemini.citi.dao;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.exception.CustomerNotFoundException;
import com.capgemini.citi.exception.InsuffiecientBalanceException;
import com.capgemini.citi.exception.SenderReceiverSameException;

public interface IDao {
	String withdraw(double amount,long mobNo) throws InsuffiecientBalanceException;
	String deposit(double amount,long mobNo);
	String fundTransfer(double amount,long mobNo1,long mobNo2) throws InsuffiecientBalanceException, SenderReceiverSameException;
    String insertCustomer(Customer customer);
	boolean checkCredentials(long mobileNo);
	public double showBalance(long mobileNo);
	public Customer login(long mobNo, String password) throws CustomerNotFoundException;// throws CustomerNotFoundException;
	public void printTransaction(long mobNo);
	//boolean login(String mobNo);

}
