package com.capgemini.citi.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.exception.InsuffiecientBalanceException;
import com.capgemini.citi.service.IService;
import com.capgemini.citi.service.ServiceClass;

public class WithDrawTest {
	IService service = null;
	Customer cust;

	@Before
	public void setUp() throws Exception {
		service = new ServiceClass();
	}

	@Test
	public void checkWithDraw() {

		Customer customer = new Customer("Tushar", "t@g.c", 4000, 8286703935L,
				"password");
		service.insertCustomer(customer);

		String result;
		try {
			result = service.withdraw(2000, 8286703935L);
			assertNotNull(result);
		} catch (InsuffiecientBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void checkWithDraw2() {

		Customer customer = new Customer("Tushar", "t@g.c", 1000, 8286703935L,
				"password");
		service.insertCustomer(customer);

		String result;
		try {
			result = service.withdraw(2000, 8286703935L);
			assertNotNull(result);
		} catch (InsuffiecientBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@After
	public void destroy() throws Exception {
		service = null;

	}
}
