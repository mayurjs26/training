package com.capgemini.citi.service;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.ResolvableType;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.bean.TransactionEntries;
import com.capgemini.citi.dao.DaoImpl;
import com.capgemini.citi.dao.IDao;

import com.capgemni.citi.exception.*;
//import com.capgemini.citi.dao.DaoClass;

@Service("service")

public class ServiceClass implements IService {
	@Autowired
	IDao dao;

	@Override
	public boolean validateName(String name) {
		if (name.matches(NamePattern))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateMobile(String mobile) {
		if (mobile.matches(mobilePattern))
			return true;
		else
			return false;
	}

	public boolean validateUsername(String username) {
		if (username.matches(userNamePattern)) {
			return true;
		} else
			return false;

	}

	@Override
	public boolean validateEmail(String email) {
		if (email.matches(emailPattern))
			return true;
		else
			return false;
	}

	public boolean validatePassword(String password) {
		if (password.matches(passwordPattern))
			return true;
		else
			return false;

	}

	public Customer insertCustomer(Customer customer) throws CustomerExists {
		return dao.insertCustomer(customer);
	}

	public Customer checkCredentials(long mobNo) throws SQLException {

		return dao.checkCredentials(mobNo);

	}

	public String deposit(double amount, Customer customer) throws CustomerNotFoundException {
		return dao.deposit(amount, customer);
	}

	public String withdraw(double amount, Customer customer) throws InsuffiecientBalanceException {

		return dao.withdraw(amount, customer);
	}

	public double showBalance(Customer customer) throws SQLException {
		return dao.showBalance(customer);
	}

	public Customer login(long mobNo, String password) {

		try {
			return dao.login(mobNo, password);
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}

		return null;
	}

	public String fundTransfer(Customer customer1, Customer customer2, double amount)
			throws InsuffiecientBalanceException, SenderReceiverSameException {

		return dao.fundTransfer(amount, customer1, customer2);
	}

	public List<TransactionEntries> printTransaction(long mobNo) {
		return dao.printTransaction(mobNo);
	}

}
