package com.capgemini.citi.jpa;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.bean.TransactionEntries;
import com.capgemini.citi.jpa.IDao;
import com.capgemini.citi.exception.CustomerExists;
import com.capgemini.citi.exception.CustomerNotFoundException;
import com.capgemini.citi.exception.InsuffiecientBalanceException;
import com.capgemini.citi.exception.SenderReceiverSameException;


public class DaoJPAClass implements IDao {
	EntityManager entityManager;
	public DaoJPAClass() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public String withdraw(double amount, Customer customer)
			throws InsuffiecientBalanceException {
		customer.setBalance(customer.getBalance()-amount);
		TransactionEntries tran = new TransactionEntries("DR",amount,customer.getBalance(),customer.getMobileNo());
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.persist(tran);
		entityManager.getTransaction().commit();
		
		
		 return "Rs." + amount + " debited from account "
				+ customer.getCustId() + " on "
				+ LocalDateTime.now() + "\nNew Balance is Rs."
				+ customer.getBalance();
	}

	@Override
	public String deposit(double amount, Customer customer)
			throws CustomerNotFoundException {
		customer.setBalance(customer.getBalance()+amount);
		entityManager.getTransaction().begin();
		TransactionEntries tran = new TransactionEntries("CR",amount,customer.getBalance(),customer.getMobileNo());
		entityManager.persist(customer);
		entityManager.persist(tran);
		entityManager.getTransaction().commit();
		
		 return "Rs." + amount + " credited on account "
				+ customer.getCustId() + " on " + LocalDateTime.now()
				+ "\nNew Balance is Rs." + customer.getBalance();
	}

	@Override
	public String fundTransfer(double amount, Customer cust1, Customer cust2)
			throws InsuffiecientBalanceException, SenderReceiverSameException {
		withdraw(amount,cust1);
		try {
			deposit(amount,cust2);
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}

	@Override
	public Customer insertCustomer(Customer customer) throws CustomerExists {
		double custId = Math.floor(Math.random()*100);
		customer.setCustId(custId);
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		
		entityManager.getTransaction().commit();
		return customer;
	}

	@Override
	public Customer checkCredentials(long mobileNo) throws SQLException {
		
		entityManager.getTransaction().begin();
		Customer cust = entityManager.find(Customer.class, mobileNo);
		entityManager.getTransaction().commit();
		return cust;
	}

	@Override
	public double showBalance(Customer customer) throws SQLException {
		double bal = entityManager.find(Customer.class, customer.getMobileNo()).getBalance();
		return bal;
	}

	@Override
	public Customer login(long mobNo, String password)
			throws CustomerNotFoundException {
		
		Customer cust = entityManager.find(Customer.class, mobNo);
		
		if(cust.getPassword().equals(password)){
			return cust;
		}
		else{
			System.out.println("User Id and Password are invalid");
		}
		return null;
	}

	@Override
	public List<TransactionEntries> printTransaction(long mobNo) {
		String qStr = "SELECT tran FROM TransactionEntries tran WHERE tran.mobNo=:mobNo";
	javax.persistence.TypedQuery<TransactionEntries> query = entityManager.createQuery(qStr, TransactionEntries.class);
		List<TransactionEntries> l = query.setParameter("mobNo", mobNo).getResultList();
		
		
		return l;
	}

}
