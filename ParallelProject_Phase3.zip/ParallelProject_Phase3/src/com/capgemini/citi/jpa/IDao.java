package com.capgemini.citi.jpa;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.bean.TransactionEntries;
import com.capgemini.citi.exception.CustomerExists;
import com.capgemini.citi.exception.CustomerNotFoundException;
import com.capgemini.citi.exception.InsuffiecientBalanceException;
import com.capgemini.citi.exception.SenderReceiverSameException;

public interface IDao {
	String withdraw(double amount, Customer customer) throws InsuffiecientBalanceException;

	String deposit(double amount, Customer customer) throws CustomerNotFoundException;

	String fundTransfer(double amount, Customer cust1, Customer cust2)
			throws InsuffiecientBalanceException, SenderReceiverSameException;

	Customer insertCustomer(Customer customer) throws CustomerExists;

	Customer checkCredentials(long mobileNo) throws SQLException;

	public double showBalance(Customer customer) throws SQLException;

	public Customer login(long mobNo, String password) throws CustomerNotFoundException;// throws
																						// CustomerNotFoundException;

	public List<TransactionEntries> printTransaction(long mobNo);
	// boolean login(String mobNo);

	long ids = 10002;

	String insertCustomer = "insert into customer99" + "(customerID,name,email," + "mobileNumber,password,"
			+ "balance)" + " values" + "(?,?,?,?,?,?)";

	String insertTransaction = "insert into transaction" + "(tid,mobno,type,amount,balance)" + " values"
			+ "(tid_seq.nextval,?,?,?,?)";

	String findUser = "select * from customer99 where mobilenumber=? and password=?";

	String getLastestId = "SELECT MAX(customerID)FROM customer99";

	String checkIfUserExists = "SELECT COUNT(customerID) FROM customer99 where mobilenumber=?";

	String withDrawMoney = "UPDATE customer99 SET balance=? WHERE customerid=?";

	String depositMoney = "UPDATE customer99 SET balance=? WHERE mobilenumber=?";

	String findReciever = "select * from customer99 where mobilenumber=?";

	String findTransaction = "SELECT * FROM transaction WHERE mobno=?";

	String showBalanceQuery = "select balance from customer99 where mobileNo= ?";

	String fetchQuery2 = "select * from customer99 where mobileNo=?";

}
