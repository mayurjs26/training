package com.capgemini.citi.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.citi.bean.Customer;
import com.capgemini.citi.jpa.*;


public class Test {

	public static void main(String[] args) {
		EntityManager em = JPAUtil.getEntityManager();
		em.getTransaction().begin();
		Customer cust = new Customer();
		cust.setName("htfjhtf");
		cust.setMobileNo(8067887674l);
		cust.setBalance(1000);
		cust.setEmail("mayur@gmail.com");
		em.persist(cust);
		em.getTransaction().commit();
		
		System.out.println("Added one student to database.");
		em.close();
		

	}

}
