package com.cg.rest.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.rest.dao.ProductRepo;

@Service
@Transactional
public class ProdutServiceImpl implements ProductService {
	
	@Autowired
	ProductRepo repo;

	public void saveProduct(Product p) {
		repo.saveProduct(p);

	}

	public Product get(int id) {
		return repo.get(id);
	}

	public List<Product> getAll() {
		return repo.getAll();
	}

}
