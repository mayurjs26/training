package com.capgemini.xyz.dao;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.TransactionDatas;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.InsufficientBalanceException;

@Repository("customerDAO")
@Transactional
public class CustomerJpaDao implements ICustomerDAO, ApplicationContextAware {

	@PersistenceContext(unitName = "SpringJPA")
	EntityManager manager;

	@Autowired
	private ApplicationContext context;

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer createCustomer(Customer customer) throws CustomerExists {
		TypedQuery<Long> query = manager.createQuery(
				"SELECT COUNT(cust.customerId) FROM Customer cust where cust.mobileNumber=:pMob", Long.class);
		query.setParameter("pMob", customer.getMobileNumber());
		long count = query.getSingleResult();

		if (count < 1) {
			manager.persist(customer);
			TransactionDatas recordTrans = (TransactionDatas) context.getBean(TransactionDatas.class);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("CR");
			recordTrans.setAmount(customer.getBalance());
			recordTrans.setBalance(customer.getBalance());
			manager.persist(recordTrans);
			return customer;
		} else {
			throw new CustomerExists("Customer Already Exists");
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String withDraw(Customer customer, double amount) throws InsufficientBalanceException {
		if (amount <= customer.getBalance() - 100) {
			customer.setBalance(customer.getBalance() - amount);

			TransactionDatas recordTrans = (TransactionDatas) context.getBean(TransactionDatas.class);
			recordTrans.setMobileNo(customer.getMobileNumber());
			recordTrans.setType("DB");
			recordTrans.setAmount(amount);
			recordTrans.setBalance(customer.getBalance());
			manager.persist(recordTrans);
			return "Rs." + amount + " debited from account " + customer.getCustomerId() + " on " + LocalDateTime.now()
					+ "\nNew Balance is Rs." + customer.getBalance();
		} else {
			throw new InsufficientBalanceException("You Have Insufficient Fund.");
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String deposit(Customer customer, double amount) throws CustomerNotFoundException {

		customer.setBalance(customer.getBalance() + amount);
		TransactionDatas recordTrans = (TransactionDatas) context.getBean(TransactionDatas.class);
		recordTrans.setMobileNo(customer.getMobileNumber());
		recordTrans.setType("CR");
		recordTrans.setAmount(amount);
		recordTrans.setBalance(customer.getBalance());
		manager.persist(recordTrans);
		return "Rs." + amount + " credited on account " + customer.getCustomerId() + " on " + LocalDateTime.now()
				+ "\nNew Balance is Rs." + customer.getBalance();
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer checkUser(String username, String password) throws CustomerNotFoundException {
		TypedQuery<Customer> query = manager.createQuery(
				"Select cust FROM Customer cust WHERE cust.mobileNumber=:pMob AND cust.password=:pPass",
				Customer.class);
		query.setParameter("pMob", username);
		query.setParameter("pPass", password);
		if (query.getResultList().size() != 0) {
			Customer customer = query.getSingleResult();
			return customer;
		} else {
			throw new CustomerNotFoundException("Invalid Credentials");
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public List<TransactionDatas> printTransaction(Customer customer) {
		Query query = manager.createQuery("SELECT tran FROM TransactionDatas tran WHERE tran.mobileNo=:pMob",
				TransactionDatas.class);
		query.setParameter("pMob", customer.getMobileNumber());
		List<TransactionDatas> list = query.getResultList();
		return list;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public Customer isValidUser(String mobileNumber) throws CustomerNotFoundException {

		TypedQuery<Customer> query = manager.createQuery("SELECT cust FROM Customer cust WHERE cust.mobileNumber=:pMob",
				Customer.class);
		query.setParameter("pMob", mobileNumber);
		if (query.getResultList().size() != 0) {
			Customer customer = query.getSingleResult();
			return customer;
		} else {
			throw new CustomerNotFoundException("No User Found With Given Mobile Number");
		}
	}

	@Override
	public double checkBalance(Customer customer) {
		return customer.getBalance();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context = applicationContext;
	}

}