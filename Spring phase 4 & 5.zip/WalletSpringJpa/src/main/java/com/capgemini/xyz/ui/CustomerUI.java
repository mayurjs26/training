package com.capgemini.xyz.ui;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.TransactionDatas;
import com.capgemini.xyz.dao.ICustomerDAO;
import com.capgemini.xyz.exception.CustomerExists;
import com.capgemini.xyz.exception.CustomerNotFoundException;
import com.capgemini.xyz.exception.IllegalFormatException;
import com.capgemini.xyz.exception.InsufficientBalanceException;
import com.capgemini.xyz.service.CustomerService;
import com.capgemini.xyz.service.CustomerServiceInterface;

@Controller
public class CustomerUI { 
	
	public static void main(String[] args) {
		
		System.out.println("Establishing Connection.....");
		
		// = new CustomerService();
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		CustomerServiceInterface service = (CustomerServiceInterface) ctx.getBean("service");
		
		System.out.println("Connection Established..!!");
		Scanner scan = new Scanner(System.in);

		// Asks for Inputs
		for (;;) {
			System.out.println("Welcome to XYZ Wallet\n1) Register\n2) Login \n3) Exit");
			String homeChoice = "";

			while (true) {
				homeChoice = scan.next();
				try {
					//validate if input between 1-3
					if (service.validateHomeChoice(homeChoice))
						break;
				} catch (IllegalFormatException e) {
					System.out.println(e.getMessage());
				}
			}

			if (homeChoice.equals("1"))// register code
			{
				Customer newCustomer = new Customer();
				while (true)// take name
				{
					System.out.println("Enter name with first letter in Capital");
					String temp = scan.next();
					try {
						//validate name
						if (service.validateName(temp)) {
							newCustomer.setName(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// take email
				{
					System.out.println("Enter email Id");
					String temp = scan.next();
					try {
						//validate email
						if (service.validateEmail(temp)) {
							newCustomer.setEmail(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// take mobile
				{
					System.out.println("Enter Mobile No");
					String temp = scan.next();
					try {
						//validate mobile number
						if (service.validateMobNo(temp)) {
							newCustomer.setMobileNumber(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}
				while (true)// set password
				{
					System.out.println("Set Password");
					String temp = scan.next();
					try {
						//validate password
						if (service.validatePassword(temp)) {
							newCustomer.setPassword(temp);
							break;
						}
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
				}

				// set balance
				newCustomer.setBalance(5000);

				// try to create new user and also checks if user exists
				try {
					Customer cust = service.createCustomer(newCustomer);
					System.out.println("New Customer Created");
					System.out.println(cust);
					cust = new Customer();
				} catch (CustomerExists e) {
					System.out.println(e.getMessage());
				}

			}// end of register
			
			else if (homeChoice.equals("2"))// login code
			{
				Customer loggedCustomer = new Customer();
				
				while (true) {
					System.out.println("Enter Mobile no");
					String temp = scan.next();
					System.out.println("Enter Password");
					String pass = scan.next();
					try {
						//get customer from login
						loggedCustomer = service.checkUser(temp, pass);
						break;
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
					}
				}

				while (true)// start submenu
				{
					System.out.println("Welcome "+loggedCustomer.getName());
					System.out.println("1) Show Balance");
					System.out.println("2) Deposit");
					System.out.println("3) Withdraw");
					System.out.println("4) Fund Transfer");
					System.out.println("5) Print Transactions");
					System.out.println("6) Logout");
					String choice = "";
					boolean isLogOut = false;

					while(true)
					{
						choice = scan.next();
					try {
						//validate if input between 1-6
						if (service.validateMenuChoice(choice))
							break;
					} catch (IllegalFormatException e) {
						System.out.println(e.getMessage());
					}
					}
					
					switch (choice) {
					case "1":
						System.out.println("Balance is Rs."+ service.checkBalance(loggedCustomer));
						break;

					case "2":
						while (true) {
							System.out.println("Enter amount to deposit");
							choice = scan.next();
							try {
								//validate if amount input is valid
								if (service.validateAmount(choice))
									break;
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}
						}

						String depositResult="";
						try {
							depositResult = service.deposit(loggedCustomer,
							Double.parseDouble(choice));
						} catch (NumberFormatException e1) {
								System.out.println(e1.getMessage());
						} catch (CustomerNotFoundException e1) {
							System.out.println(e1.getMessage());
						}
						//print result from server
						System.out.println(depositResult);
						break;

					case "3":
						while (true) {
							System.out.println("Enter amount to withdraw");
							choice = scan.next();
							try {
								//validate if amount input is valid
								if (service.validateAmount(choice))
									break;
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}
						}//end of while

						try {
							String withdrawResult = service.withDraw(
									loggedCustomer,
									Double.parseDouble(choice));
							System.out.println(withdrawResult);
						} catch (NumberFormatException
								| InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						}
						break;

					case "4":
						
						String mob="";
						String amt="";
						Customer reciever = null;
						while(true)
						{
							System.out.println("Enter mobile number of other user");
							 mob = scan.next();
							System.out.println("Enter the amount");
							 amt = scan.next();
							
							try {
								if(service.validateMobNo(mob) && service.validateAmount(amt))
								{
									reciever = service.isValidUser(mob);
									break;
								}
									
							} catch (IllegalFormatException e) {
								System.out.println(e.getMessage());
							}catch (CustomerNotFoundException e) {
								System.out.println(e.getMessage());
							}						
						}

						//store fund transfer results
						try {
							String[] data = service.fundTransfer(
									loggedCustomer, reciever,
									Double.parseDouble(amt));
							for (String result : data) {
								System.out.println(result);
							}
						} catch (NumberFormatException
								| InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						} catch (CustomerNotFoundException e) {
							System.out.println(e.getMessage());
						}
						break;

					case "5":
						List<TransactionDatas> list = 
							service.printTransaction(loggedCustomer);
						System.out.println(list);
						break;

					case "6":
						//logout user
						isLogOut = true;
					default:
						break;
					}

					if (isLogOut) {
						isLogOut = false;
						break;
					} else
						continue;
				}
			}// end of login code
			else { //if choice is 3 ie exit
					System.out.println("Exited Successfully. Thank You. Visit Again");
					break;
			}
		}// end of eternal loop
	}
}
