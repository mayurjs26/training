package com.cg.client;

import com.cg.entity.Product;
import com.cg.repo.ProductRepoImpl;

public class ProductClient {

	public static void main(String[] args) {
		
		Product p1 = new Product("Book", 200);
		Product p2 = new Product("Deo", 195);
		Product p3 = new Product("DVD", 100);
		
		ProductRepoImpl pr = new ProductRepoImpl();
		
		pr.saveProduct(p1);
		pr.saveProduct(p2);
		pr.saveProduct(p3);
		
		System.out.println(pr.get(201));
		
		System.out.println(pr.getAll());
		
	}

}
