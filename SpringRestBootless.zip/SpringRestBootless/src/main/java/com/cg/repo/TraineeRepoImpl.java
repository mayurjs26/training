/**
 * 
 */
package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;

/**
 * @author mayur
 *
 */

@Repository

public class TraineeRepoImpl implements TraineeRepo {

	@PersistenceContext(unitName = "SpringJpa")
	private EntityManager em;

	public void addTrainee(Trainee trainee) {
		 em.persist(trainee);
	}

	public boolean deleteTrainee(int id) {
		Trainee trainee = em.find(Trainee.class, id);
		em.remove(trainee);
		return true;
		
	}

	public void modifyTrainee(Trainee trainee) {
		em.merge(trainee);
		
	}

	public Trainee findTraineeById(int id) {
		return em.find(Trainee.class, id);
	}

	public List<Trainee> findAllTrainee() {
		
		return em.createQuery("from Trainee").getResultList();
	}
}
