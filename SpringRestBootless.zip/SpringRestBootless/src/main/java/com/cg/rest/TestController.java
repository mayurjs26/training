package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Trainee;
import com.cg.service.TraineeService;


@Scope("session")
@Controller
public class TestController {
	
	@Autowired
	TraineeService service;
	
	List<String> traineeLocation;
	List<String> traineeDomain;
	
	@RequestMapping(value="loginvalidation")
	public String loginValidation(@RequestParam("username") String username,@RequestParam("password") String password)
	{
		if(username.equals("admin") && password.equals("mayur@26"))
		{
			return "options";
		}
		else {
			return "login";
		}
	}

	
	@RequestMapping(value="register")
	public String register() {
		traineeLocation = new ArrayList<String>();
		traineeLocation.add("Mumbai");
		traineeLocation.add("Banglore");
		traineeLocation.add("Pune");
		traineeLocation.add("Chennai");
		
		traineeDomain = new ArrayList<String>();
		traineeDomain.add("JEE");
		traineeDomain.add("SAP");
		traineeDomain.add(".NET");
		traineeDomain.add("MainFrame");
		
		
		return "options";
	}
	@RequestMapping(value="login")
	public String login() {
		return "login";
		
	}
	@RequestMapping(value="/options")
	public String menu(@RequestParam("id") String id) {
		return id;
	}
	
	@RequestMapping(value="add")
	public String addTrainee(@ModelAttribute("addTrainee") Trainee trainee,Model model) {
		
		
		 service.addTrainee(trainee);
		 model.addAttribute("result","Trainee Added Successfully");
		
		return "addtrainee";
		
	}
	
	@RequestMapping(value="delete")
	public String deleteTrainee(@RequestParam("id") int id,Model model) {
		
		boolean delete = service.deleteTrainee(id);
		if(delete) {
			model.addAttribute("result", "Trainee Deleted Successfully");
		}
		else {
			model.addAttribute("result", "Trainee Not Found");
		}
		return "delete";
	}
	@RequestMapping("update")
	public String updateTrainee(@RequestParam("id") int id ,@ModelAttribute("trainee") Trainee trainee,Model model) {
		Trainee t = service.findTraineeById(id);
		service.modifyTrainee(t);
		model.addAttribute("result", "Updated SuccessFully");
		return "update";
	}
	@RequestMapping("findbyid")
	public String findById(@RequestParam("id") int id,Model model) {
		
		Trainee t = service.findTraineeById(id);
		model.addAttribute("result", "Updated Successfully");
		return "findbyid";
	}
}

