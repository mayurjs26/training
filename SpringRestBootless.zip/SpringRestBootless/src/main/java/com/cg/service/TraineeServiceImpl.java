/**
 * 
 */
package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

/**
 * @author mayur
 *
 */

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService{
	
	@Autowired
	TraineeRepo repo;
	
	@Transactional(propagation = Propagation.REQUIRED)
	public void addTrainee(Trainee trainee) {
		repo.addTrainee(trainee);
		
	}
	@Transactional(propagation = Propagation.SUPPORTS)
	public boolean deleteTrainee(int id) {
		return repo.deleteTrainee(id);
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public void modifyTrainee(Trainee trainee) {
		repo.modifyTrainee(trainee);
	}
	@Transactional
	public Trainee findTraineeById(int id) {
		return repo.findTraineeById(id);
	}
	@Transactional
	public List<Trainee> findAllTrainee() {
		return repo.findAllTrainee();
	}

}
