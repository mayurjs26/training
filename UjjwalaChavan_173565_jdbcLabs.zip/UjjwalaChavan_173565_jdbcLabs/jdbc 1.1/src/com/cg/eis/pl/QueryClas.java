package com.cg.eis.pl;

import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeInterface;
import com.cg.eis.service.EmployeeService;

public class QueryClas {

	public static void main(String[] args) {
		System.out.println("Connecting.....");
		
		EmployeeInterface service = new EmployeeService();
		
		System.out.println("Connected....");
		Scanner scanner = new Scanner(System.in);
		
		for(;;)
		{
			System.out.println("WElcome");
			System.out.println("Select a menu");
			System.out.println("1. Get Employee by id\n2. Get Insurance Scheme \n3. Get All Employee\n4. Exit");
			
			String input = scanner.next();
			boolean islogout = false;
			switch(input)
			{
			case "1": 
				System.out.println("Enter Employee ID");
				String id = scanner.next();
				try {
					Employee e = service.displayEmployeeById(Integer.parseInt(id));
					System.out.println(e);
				} catch (NumberFormatException e) {
					System.out.println("Invalid inputs");
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				break;
			case "2":
				System.out.println("Enter Employee ID");
				String ids = scanner.next();
				try {
					String result = service.getInsuranceScheme(Integer.parseInt(ids));
					System.out.println(result);
				} catch (NumberFormatException e) {
					System.out.println("Invalid inputs");
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
				}
				
				break;
				
			case "3":
				Map<Integer, Employee> data = service.displayEmployees();
				
				data.entrySet().stream().forEach(System.out::println);
				
				break;
				
			case "4": islogout = true; break;	
			default : break;	
			}
			
			if(islogout)
			{
				islogout = false;
				break;
			}
				
		}
	
	}
}
