/*create table author (authorId number primary key,firstName varchar2(20),middleName varchar2(20),lastName varchar2(20),phoneNo number);
create table book(ISBN number primary key,title varchar2(20),price number);
create table bookauthorref(id number primary key,bookid number,Authorid number,foreign key(bookid) references book(ISBN),FOREIGN KEY(authorid) references author(authorid));
create sequence seq_author
  minvalue 1
  start with 1
 increment by 1
  cache 10;

Sequence created.

SQL> create sequence seq_isbn
  minvalue 1
  start with 1
 increment by 1
  cache 10;

Sequence created.

SQL> create sequence seq_refid
  minvalue 1
  start with 1
  increment by 1
  cache 10;*/

package com.cg.xyz.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.xyz.bean.Author;
import com.cg.xyz.bean.Book;
import com.cg.xyz.dao.DatabaseDao;

public class MainExecutor {
	public static void main(String[] args) throws SQLException {
		System.out.println("Hiii");
		Scanner sc = new Scanner(System.in);
		int ch = 0;
		String fname;
		String mName;
		String lName;
		long mob;
		String title;
		Double price;
		int authId;
		DatabaseDao dao = new DatabaseDao();

		for(;;){
		System.out
				.println("1. Enter Author details and Book\n2. See Authors \n3.	Add Book of Existing author\n4.	 Get Books of Author\n5.	Exit");
		
		ch = sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("enter Author First name");
			fname = sc.next();
			System.out.println("enter Author middle Name");
			mName = sc.next();
			System.out.println("enter Author last name");
			lName = sc.next();
			System.out.println("enter Phone no");
			mob = sc.nextLong();
			System.out.println("Book Title");
			title = sc.next();
			System.out.println("Book price");
			price = sc.nextDouble();
			Author auth = new Author(fname, mName, lName, mob);
			Book book = new Book(title, price);
			dao.insertIntodatabase(auth, book);
			break;
		case 2:
			System.out.println(dao.getAuthor());
			break;
		case 3:
			System.out.println("enter author Id");
			authId = sc.nextInt();
			System.out.println("Book Title");
			title = sc.next();
			System.out.println("Book price");
			price = sc.nextDouble();
			Book book1 = new Book(title, price);
			dao.insertIntobook(authId, book1);
			break;
		case 4:
			System.out.println("enter author Id");
			authId = sc.nextInt();
			System.out.println(dao.getBook(authId));
			break;
		case 5:
			System.exit(0);
		default:
			break;
		}

	}
	}

}
