export class CustomerModel{

    public id:number;
    public name:String;
    public age:number;
    public gender:string;
}