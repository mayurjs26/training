package com.cg.ctlr;

//import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Login {
	
	//@NotEmpty(message="UserName Cant be Empty")
	
@NotEmpty(message="Username empty")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String userName;
	@NotEmpty(message="Password Cant be Empty")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
