import { Component, OnInit } from '@angular/core';
import { EmployeeModel } from '../models/Employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  employeeArr : EmployeeModel[];
  employeeToEdit:EmployeeModel;
  isEditing:boolean;


  constructor(private empservice:EmployeeService) {
    this.employeeArr=[];
    this.employeeToEdit = new EmployeeModel();

   }

  ngOnInit() {
    this.employeeArr = this.empservice.getEmployees();
  }

  sort(){
    this.empservice.sortEmp();
  }

  delete(index:number){
    this.empservice.delete(index);
  }

  edit(index:number){
    this.isEditing = true;
    this.employeeToEdit = this.empservice.edit(index);
  }

}
