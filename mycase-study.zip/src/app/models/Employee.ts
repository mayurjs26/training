export class EmployeeModel{
    employeeId:number;
    employeeName:string;
    employeeGender:string;
    employeeDepartment:string;
    employeeSalary:number;
}