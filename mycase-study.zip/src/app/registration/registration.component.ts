import { Component,  Input,EventEmitter, Output } from '@angular/core';
import { EmployeeModel } from '../models/Employee';
import { EmployeeService } from '../employee.service';
import  {FormsModule} from '@angular/forms';

@Component({
  selector: 'registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {

  @Input() employee : EmployeeModel;
  @Input() isEditing : boolean;
  @Output() edited = new EventEmitter();


  constructor(private empService: EmployeeService) { 

this.employee = new EmployeeModel();
  }

  

  add(){
    this.empService.add(this.employee);
    this.employee = new EmployeeModel();
  }

  update(){
    this.isEditing = false;
    this.employee = new EmployeeModel();
    this.edited.emit();
  }

}

