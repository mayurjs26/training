import { Component, OnInit } from '@angular/core';
import { StudentServiceService } from '../services/student-service.service';
import { Student } from '../models/StudentModel';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
studentArr : Student[];
studentToEdit:Student;
isEditing : boolean;

  constructor(private studentser:StudentServiceService) {
    this.studentArr = [];
    this.studentToEdit = new Student();
   }

   delete(i: number){
     this.studentser.delete(i);
   }

   edit(index:number){
    this.isEditing = true;
    this.studentToEdit = this.studentser.edit(index);

   }
   sortByMarks(){
     return this.studentser.sortByMarks();
   }

  ngOnInit() {
   this.studentArr=  this.studentser.getStudents();
  }

}
