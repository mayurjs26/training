import { Component, OnInit, Input } from '@angular/core';
import { StudentServiceService } from '../services/student-service.service';
import { Student } from '../models/StudentModel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 @Input() student : Student;
  constructor(private studentser:StudentServiceService) {


   }

  ngOnInit() {
  }

  login(username:string,password:string){
return this.studentser.login(username,password);
  }


}
