export class Student{
    public rollNo : number;
    public name : string;
    public aggregate:number;
    public class : string;
    public password:string;
}
