import { Component, OnInit, Input, EventEmitter,Output } from '@angular/core';
import { StudentServiceService } from '../services/student-service.service';
import { Student } from '../models/StudentModel';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
 @Input() student = new Student();
 @Input() isEditing : boolean;
 
 @Output() edited = new EventEmitter();

  constructor(private studentser: StudentServiceService) {
    this.student = new Student();
  }

  ngOnInit() {
  }

  add(){
    this.studentser.add(this.student);
    this.student = new Student();
  }

  update(){
    this.isEditing = false;
    this.student = new Student();
    this.edited.emit();
  }

}
