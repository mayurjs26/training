import { Component, OnInit } from '@angular/core';
import { StudentServiceService } from '../services/student-service.service';
import { Student } from '../models/StudentModel';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
result:Student;

  constructor(private studentser:StudentServiceService) {
    this.result = new Student();
   }

  ngOnInit() {

  }

  searchStudent(index: number){
  this.result = this.studentser.studentArr.find(x => x.rollNo === index);


}
}
