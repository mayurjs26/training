import { Injectable } from '@angular/core';
import { Student } from '../models/StudentModel';
import {Router} from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class StudentServiceService {
  studentArr : Student[];
  result:Student;


  constructor(private routes: Router) {
    this.studentArr = [];
  }

  add(student:Student){
    this.studentArr.push(student);
   // this.routes.navigate(['/display']);
   this.routes.navigate(['/login']);
  }
  delete(index:number){
    this.studentArr.splice(index,1);
  }
  getStudents(){
    return this.studentArr;
  }
  searchStudent(rN:number){
    var result = this.studentArr.find(x => x.rollNo == rN);
    if(result==null)
    return null;
    else
    return result;
  }

  edit(rN:number){
   return this.studentArr.find(x => x.rollNo==rN);
  }

  login(username:string,password:string){
    this.result = this.studentArr.find(x => x.name===username);

    if(this.result.password === password){

      this.routes.navigate(['/display']);
    }
    else
    return false;
  }

  sortByMarks(){
    this.studentArr.sort((a,b) => a.aggregate - b.aggregate);
    return this.studentArr;
  }
}
