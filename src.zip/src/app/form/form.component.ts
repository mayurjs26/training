import { Component, OnInit } from '@angular/core';

import { Student } from '../model/customer';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  
})
export class FormComponent  {
title:string;
StudentArr: Student[];
student:Student;
id:number;
  constructor() {
    this.title = "form";
    this.StudentArr = [];
    this.student = new Student();
    this.id = 0;

   }
add(){
  this.student.id = this.StudentArr.length+1;
  this.StudentArr.push(this.student);
  this.student = new Student();
}

edit(index:number){
  this.student = this.StudentArr[index];
  this.id = index;
}
  remove(index : number){
    this.StudentArr.splice(index,1);
  }

}
