export class Student{
    name: string;
    age:number;
    mobileno:string;
    id:number;
}
